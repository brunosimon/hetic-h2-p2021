<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Mon site</title>
	<link rel="stylesheet" href="<?= URL ?>assets/style/main.css">
</head>
<body>
	<header><a href="<?= URL ?>">Mon site</a></header>