	<footer>
		Mon footer
		<br><a href="<?= URL ?>contact">Contact</a>
	</footer>
</body>
</html>