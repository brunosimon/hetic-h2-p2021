<h1>Bienvenue sur mon site</h1>

<div>
	<h3>Article toto</h3>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur facilis fugit omnis sint doloremque, dignissimos nobis accusantium veritatis! Voluptatibus quam reiciendis fugiat assumenda nulla voluptatum iure distinctio maxime id dolor!</p>
	<a href="<?= URL ?>article?id=1">Lire la suite</a>
</div>
<div>
	<h3>Article tata</h3>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit quibusdam odit ex vel molestias inventore pariatur ipsa saepe, consequatur doloribus necessitatibus hic alias. Harum ipsa maxime, quam earum expedita itaque.</p>
	<a href="<?= URL ?>article?id=2">Lire la suite</a>
</div>
<div>
	<h3>Article tutu</h3>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente impedit et porro ad doloribus itaque delectus eaque, debitis pariatur possimus facilis, qui labore assumenda reiciendis dolorem explicabo veniam obcaecati repellendus.</p>
	<a href="<?= URL ?>article?id=3">Lire la suite</a>
</div>