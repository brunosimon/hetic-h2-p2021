<?php
    include 'config.php';

    include 'views/pages/home.php';