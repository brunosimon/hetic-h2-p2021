<?php

define('URL', '/p2021/exercices/cours-19-php-routing');