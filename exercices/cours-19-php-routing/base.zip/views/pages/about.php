<?php

    $title = 'Contact';

    include 'views/partials/header.php';
?>

<h1>About</h1>
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Itaque dolorum ullam harum veniam cum eos mollitia suscipit reprehenderit dolore maiores consequuntur quod consequatur soluta, cupiditate corporis voluptatem adipisci, ipsum cumque.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis deserunt cumque repudiandae sed quas quam tempora vel doloribus vitae, consectetur possimus incidunt architecto qui molestias magni aut delectus ex alias?</p>


<?php include 'views/partials/footer.php'; ?>