<?php

    $title = '404';

    include 'views/partials/header.php';
?>

<h1>404</h1>

<?php include 'views/partials/footer.php'; ?>