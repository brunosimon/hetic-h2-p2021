<?php

    $title = 'Mon site';

    include 'views/partials/header.php';
?>

<h1>Home</h1>

<li><a href="#">Article 1</a></li>
<li><a href="#">Article 2</a></li>
<li><a href="#">Article 3</a></li>

<?php include 'views/partials/footer.php'; ?>