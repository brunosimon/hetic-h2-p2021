<?php

    $title = 'Article';

    include 'views/partials/header.php';
?>

<h1>Article <?= $_GET['id'] ?></h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt accusamus, iste laborum at a rerum maiores iusto. Odit, dolorem architecto, maxime nesciunt optio rem alias reiciendis nemo reprehenderit quasi unde.</p>

<?php include 'views/partials/footer.php'; ?>