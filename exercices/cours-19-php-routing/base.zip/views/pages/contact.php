<?php

    $title = 'Contact';

    include 'views/partials/header.php';
?>

<h1>Contact</h1>
<form action="#">
    <div>
        <input type="text"> Email
    </div>
    <div>
        <input type="text"> Sujet
    </div>
    <div>
        message
        <br>
        <textarea></textarea>
    </div>
</form>

<?php include 'views/partials/footer.php'; ?>